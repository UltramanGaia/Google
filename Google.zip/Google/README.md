# Google
This small bat is to help windows users in China access Google.com
You only need to run the google.bat as Administrator and wait for a monent.

Thank for "https://coding.net/u/scaffrey/p/hosts/git/raw/master/hosts"
